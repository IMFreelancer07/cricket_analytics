from langchain_community.document_loaders.polars_dataframe import PolarsDataFrameLoader

__all__ = ["PolarsDataFrameLoader"]
