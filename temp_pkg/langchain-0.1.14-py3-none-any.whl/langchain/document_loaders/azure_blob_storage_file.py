from langchain_community.document_loaders.azure_blob_storage_file import (
    AzureBlobStorageFileLoader,
)

__all__ = ["AzureBlobStorageFileLoader"]
