from langchain_community.document_loaders.parsers.docai import (
    DocAIParser,
    DocAIParsingResults,
)

__all__ = ["DocAIParsingResults", "DocAIParser"]
