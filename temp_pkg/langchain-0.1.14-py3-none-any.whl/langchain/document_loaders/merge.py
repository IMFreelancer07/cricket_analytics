from langchain_community.document_loaders.merge import MergedDataLoader

__all__ = ["MergedDataLoader"]
