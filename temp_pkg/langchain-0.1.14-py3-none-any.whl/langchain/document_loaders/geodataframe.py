from langchain_community.document_loaders.geodataframe import GeoDataFrameLoader

__all__ = ["GeoDataFrameLoader"]
