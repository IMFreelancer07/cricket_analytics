from langchain_community.chat_models.minimax import (
    MiniMaxChat,
)

__all__ = ["MiniMaxChat"]
